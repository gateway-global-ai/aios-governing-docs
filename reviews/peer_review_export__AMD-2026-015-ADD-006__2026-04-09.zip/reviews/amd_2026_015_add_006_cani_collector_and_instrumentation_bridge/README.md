# AMD-2026-015-ADD-006 review package

This review package covers the narrow collector / instrumentation bridge addendum under `AMD-2026-015` for governed capture surfaces, normalization into intake envelopes, and handoff into validator and writer lanes.

## Standard export

The standard self-contained export for this package is:

- `reviews/peer_review_export__AMD-2026-015-ADD-006__2026-04-09.zip`

Build path:

- `reviews/amd_2026_015_add_006_cani_collector_and_instrumentation_bridge/build_peer_review_export.ps1`

This export follows `AIOS-PEER-REVIEW-EXPORT-STANDARD-001`:

- `peer_review_export` means self-contained evidence archive
- repo-relative tree appears at archive root
- zip entry separators are normalized `/`
- review docs plus actual files under review are included
- unrelated repo files are excluded

The canonical source of truth remains the governed repo review package and source artifacts. For external/manual review, the canonical review artifact is the self-contained `peer_review_export__<document_id>__<date>.zip`, produced from the preserved package-local build script.

## Review target

- `amendments/AMD-2026-015-ADD-006-cani-collector-and-instrumentation-bridge.md`
- `amendments/AMD-2026-015-cani-experience-loop-and-victory-lap-formula.md`
- `amendments/AMD-2026-015-ADD-001-governed-knowledge-artifact-registry-and-declared-input-bridge.md`
- `amendments/AMD-2026-015-ADD-002-cani-observation-schema-and-recommendation-routing-bridge.md`
- `amendments/AMD-2026-015-ADD-003-cani-persisted-artifact-taxonomy-and-routing-storage-bridge.md`
- `amendments/AMD-2026-015-ADD-004-cani-telemetry-ingestion-envelope-and-normalization-bridge.md`
- `amendments/AMD-2026-015-ADD-005-cani-validator-and-tooling-bridge.md`
- `reference/knowledge_base/articles/CANI-VICTORY-LAP-FORMULA.md`
- `reference/implementation/CANI-EXPERIENCE-LOOP-TECHNICAL-STANDARD-001.md`
- `reference/implementation/CANI-OBSERVATION-AND-RECOMMENDATION-SCHEMA-001.md`
- `reference/implementation/CANI-PERSISTED-ARTIFACT-TAXONOMY-AND-STORAGE-CONTRACT-001.md`
- `reference/implementation/CANI-TELEMETRY-INGESTION-ENVELOPE-AND-NORMALIZATION-CONTRACT-001.md`
- `reference/implementation/CANI-VALIDATOR-AND-TOOLING-CONTRACT-001.md`
- `reference/implementation/CANI-CAPTURE-SURFACE-AND-NORMALIZATION-HANDOFF-CONTRACT-001.md`
- `reference/implementation/AIOS-AMENDMENT-INTAKE-SCAFFOLD-001.md`
- `reference/implementation/AIOS-REVIEW-PACKET-TAXONOMY-001.md`

## What this package does

- defines which governed capture surface classes may emit CANI-relevant signals
- distinguishes raw capture from normalized intake envelopes
- defines pre-validator fail-closed handling for incomplete, ambiguous, or boundary-violating capture candidates
- defines handoff from normalized intake envelopes into validator and then writer lanes without bypassing governance

## Why an addendum is the correct instrument

`AMD-2026-015` already governs the CANI family.

`ADD-004` already governs intake envelopes.

`ADD-005` already governs validator/tooling behavior.

This pass closes the next narrower family gap:

- governed capture-surface eligibility
- normalization discipline before validator handoff
- writer-lane handoff rules without authorizing collectors or autonomy

## What this package does not do

- implement collectors
- implement browser instrumentation
- implement event-store or database services
- authorize automatic recommendation execution
- authorize autonomous routing
- modify the approved writer slice
