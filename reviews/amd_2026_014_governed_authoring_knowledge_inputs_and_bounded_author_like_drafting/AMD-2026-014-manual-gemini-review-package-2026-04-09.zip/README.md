# AMD-2026-014 review packet

This directory is the sole authoritative packet root for `AMD-2026-014`.

It owns the live governed review trace for:

- `amendments/AMD-2026-014-governed-authoring-knowledge-inputs-and-bounded-author-like-drafting.md`

The earlier dated folder:

- `reviews/governed_authoring_knowledge_package_2026-04-09/`

is a legacy package-materials helper and is not the authoritative packet root for this lane.

## Packet purpose

This packet closes the governed review path for bounded author-like knowledge inputs and bounded author-like drafting so a reviewer can trace:

- amendment
- packet
- round reviews
- synthesis
- gate
- motion
- downstream truth surfaces

without relying on shell-only materials.

## Packet structure

### Packet-root authority

- `PACKET_IDENTITY.yaml`
- `PACKET_STATUS.yaml`
- `PACKET_EVENTS.yaml`
- `HANDOFF_NOTE.md`
- `FILE_MANIFEST.md`
- `AUDIT_AND_CHANGE_HISTORY.md`
- `REVIEWER_CHECKLIST.md`

### Active round

- `round_1/`

The validator-governed round artifacts live under `round_1/` and will be the basis for `scripts/validate_review_packet.py`.

## Review target

- `amendments/AMD-2026-014-governed-authoring-knowledge-inputs-and-bounded-author-like-drafting.md`
- `reference/implementation/AIOS-GOVERNED-AUTHORING-KNOWLEDGE-INPUT-STANDARD-001.md`
- `reference/knowledge_base/agents/style/JT_EDITORIAL_STYLE_CARD.md`
- `reference/knowledge_base/agents/style/JT_NARRATION_STYLE_CARD.md`
- `reference/knowledge_base/agents/style/JT_AUTHORING_MODE_BOUNDARIES.md`
- `reference/knowledge_base/agents/style/JT_EDITORIAL_REQUIRED_KNOWLEDGE_MANIFEST.yaml`
- `reference/knowledge_base/agents/style/JT_NARRATION_REQUIRED_KNOWLEDGE_MANIFEST.yaml`
- `modelfiles/jt_authoring_agent.Modelfile`
- `scripts/ollama_authoring_agent.py`

## Current packet posture

- Packet root established
- `round_1/` opened as the active governed review round
- Actual round reviews, synthesis, gate, and motion are still pending

---

*Authoritative packet root for AMD-2026-014.*
