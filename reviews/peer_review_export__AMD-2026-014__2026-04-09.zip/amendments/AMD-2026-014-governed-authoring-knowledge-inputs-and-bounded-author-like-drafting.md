---
document_id: AMD-2026-014
version: 0.1.0
status: draft
category: amendment
title: Governed Authoring Knowledge Inputs and Bounded Author-Like Drafting
author: Gateway Global AIOS
created: 2026-04-09
last_updated: 2026-04-09
ratification_target: null
supersedes: null
cross_references:
  - doc_id: AMD-2026-005
    title: Workspace Model & Governed Interface Surfaces
  - doc_id: AMD-2026-007
    title: Intent Primitive, Shell Affordances, Session Disclosure, Workspace Domain Pack v1, and Primary vs Operator UI
  - doc_id: AMD-2026-009
    title: Intent-Scoped Web Retrieval and Governed Website Review
  - doc_id: AMD-2026-013
    title: Intent-Bearing Repository Taxonomy (Architecture and Builder Control)
  - doc_id: AIOS-AMD-PLAN-001
    title: Amendment pre-ratification planning lifecycle
  - doc_id: AIOS-AMENDMENT-INTAKE-SCAFFOLD-001
    title: Amendment intake scaffold standard
  - doc_id: AIOS-GOVERNED-AUTHORING-KNOWLEDGE-INPUT-STANDARD-001
    title: Governed authoring knowledge inputs and bounded author-like drafting
amendment_history:
  - version: 0.1.0
    date: 2026-04-09
    summary: "Draft — declare bounded author-like knowledge inputs, author identity boundaries, manifest discipline, and non-authority rules for governed drafting support."
---

# AMD-2026-014 — Governed Authoring Knowledge Inputs and Bounded Author-Like Drafting

## 0. Status

| Field | Value |
|-------|--------|
| Status | `draft` `0.1.0` |
| Scope posture | Narrow drafting-governance amendment. It governs author-like knowledge inputs and boundaries. It does not redesign architect/UI, peer review, committee, kernel review, or ratification. |

---

## 1. Purpose

This amendment defines how bounded author-like drafting support may be used in the AI OS governance repository without collapsing authority into a simulated persona.

The problem is simple:

- style guidance can improve drafting quality
- undeclared or freeform persona simulation can drift into invented authority

This amendment allows the first and blocks the second.

---

## 2. Scope

**In scope**

- declared style cards used as governed knowledge inputs
- declared authoring manifests
- bounded mode definitions
- author identity boundaries
- use of those inputs in local Ollama drafting tools
- use of those inputs by architect/UI-adjacent runs only when explicitly declared

**Out of scope**

- automatic doctrine mutation
- ratification shortcuts
- replacing architect or UI templates
- replacing peer review
- replacing committee judgment
- replacing kernel review

---

## 3. Normative decisions

### 3.1 Declared-input rule

Author-like drafting runs **SHALL** use declared knowledge inputs.

Those inputs **SHALL** be:

- inside the governed repo tree
- selected by manifest or equivalent declared input set
- traceable by path

### 3.2 Discussion-to-artifact rule

Discussion, chat, or private notes **SHALL NOT** become required knowledge for governed author-like runs until they are converted into repo artifacts with stable governed paths.

### 3.3 Bounded author identity rule

Author-like drafting support **MAY** reproduce tone, cadence, and rhetorical structure reflected in declared repo artifacts.

It **SHALL NOT** claim:

- personal memory
- unpublished strategic intent
- private conversations
- governance authority by imitation

### 3.4 Non-authority rule

Generated prose from author-like tools is advisory drafting output only.

It **MUST NOT**:

- self-ratify doctrine
- self-amend doctrine
- self-approve architect output
- self-approve UI output
- bypass committee, peer review, kernel review, or ratification lanes

### 3.5 Architect and UI relationship

Architect and UI lanes **MAY** use bounded author-like inputs only when those inputs are explicitly declared for the run.

When used:

- the planning template remains authoritative for output shape
- manifest declaration remains required
- human verification remains required
- style guidance remains subordinate to repo truth

### 3.6 Command-surface traceability

Local author-like drafting command surfaces **SHALL** expose mode selection and manifest selection explicitly. They **SHALL NOT** rely on undeclared hidden context as if it were governed knowledge.

If a command surface allows manifest override, that override **SHALL** remain compatible with the selected mode family rather than silently crossing from editorial-family inputs into narration-family inputs, or vice versa.

---

## 4. Relationship to existing governance

| Instrument | Relationship |
|------------|--------------|
| AMD-2026-005 | Ratification and peer-review gates are unchanged. Author-like drafting support does not bypass them. |
| AMD-2026-007 / AIOS-SPEC-009 | Intent and execution remain authoritative for behavior. This amendment only governs drafting inputs and boundaries. |
| AMD-2026-009 | External knowledge remains bounded and governed. Raw external discussion is not silently imported into authoring authority. |
| AMD-2026-013 | Declared repository paths remain architecture/builder-controlled. Authoring inputs must use governed paths, not ad hoc hidden stores. |
| AIOS-AMD-PLAN-001 / intake scaffold | Architect and UI remain draft-producing lanes with human verification. This amendment only constrains optional author-like inputs to those lanes. |

---

## 5. Required implementation references

The initial governed implementation surface for this amendment is documented in:

- `reference/knowledge_base/agents/style/JT_EDITORIAL_STYLE_CARD.md`
- `reference/knowledge_base/agents/style/JT_NARRATION_STYLE_CARD.md`
- `reference/knowledge_base/agents/style/JT_AUTHORING_MODE_BOUNDARIES.md`
- `reference/knowledge_base/agents/style/JT_EDITORIAL_REQUIRED_KNOWLEDGE_MANIFEST.yaml`
- `reference/knowledge_base/agents/style/JT_NARRATION_REQUIRED_KNOWLEDGE_MANIFEST.yaml`
- `reference/implementation/AIOS-GOVERNED-AUTHORING-KNOWLEDGE-INPUT-STANDARD-001.md`

These artifacts define the bounded input surface. They do not by themselves ratify any generated text.

---

## 6. Non-goals

This amendment does not:

- make the model into Jason Trindade
- authorize ghost authority
- replace authored review
- authorize hidden memory or hidden style injection

---

## 7. Amendment intent summary

The AI OS may use bounded author-like drafting support, but only when the knowledge inputs are declared, traceable, and governed. Style may support drafting. Style may not become authority.
